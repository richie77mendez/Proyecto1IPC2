/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora.gui;

/**
 *
 * @author ricardo
 */
public class calculadoraFrame extends javax.swing.JFrame {

    private calculosDiscretosFrame calculosDiscretosFrame;
    private conversionesNumericas conversionesNumericasFrame;
    
    public calculadoraFrame() {
        calculosDiscretosFrame = new calculosDiscretosFrame();
        conversionesNumericasFrame = new conversionesNumericas();
        initComponents();
        this.panel.add(calculosDiscretosFrame);
        this.panel.add(conversionesNumericasFrame);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        discretos = new javax.swing.JMenuItem();
        conversiones = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 560, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 357, Short.MAX_VALUE)
        );

        jMenu1.setText("Menus");

        discretos.setText("Calculos Discretos");
        discretos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                discretosActionPerformed(evt);
            }
        });
        jMenu1.add(discretos);

        conversiones.setText("Conversiones Numericas");
        conversiones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                conversionesActionPerformed(evt);
            }
        });
        jMenu1.add(conversiones);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Tools");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void conversionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_conversionesActionPerformed
        this.conversionesNumericasFrame.setVisible(true);
    }//GEN-LAST:event_conversionesActionPerformed

    private void discretosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_discretosActionPerformed
        this.calculosDiscretosFrame.setVisible(true);
    }//GEN-LAST:event_discretosActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem conversiones;
    private javax.swing.JMenuItem discretos;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel panel;
    // End of variables declaration//GEN-END:variables
}

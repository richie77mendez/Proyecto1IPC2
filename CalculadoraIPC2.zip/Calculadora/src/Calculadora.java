import calculadora.gui.calculadoraFrame;
import java.util.Scanner;

/**
 *
 * 
 */
public class Calculadora{

	/**
	 * Metodo principal de ejecución
	 * @param args posibles argumentos ingresados desde consola
	 */
	public static void main(String[] args) {
            
            calculadoraFrame calcu = new calculadoraFrame();
            calcu.setVisible(true);
		Scanner entrada = new Scanner(System.in);
		boolean continuarPrincipal = true;
		String opcion;
		double resultado;
		double resultadoOpBasicas = 0;
		boolean hayResultadoAnterior = false;
		do {
			//Escribir menú principal
			escribirMenuPrincipal();
			//leer opcion
			opcion = entrada.nextLine();
			switch (opcion) {
				case "1":
					//suma
					resultadoOpBasicas = sumar(entrada, hayResultadoAnterior, resultadoOpBasicas);
					escribirResultado(resultadoOpBasicas, entrada);
					hayResultadoAnterior = true;
					break;
				case "2":
					//resta
					resultadoOpBasicas = restar(entrada, hayResultadoAnterior, resultadoOpBasicas);
					escribirResultado(resultadoOpBasicas, entrada);
					hayResultadoAnterior = true;
					break;
				case "3":
					//multiplicacion
					resultadoOpBasicas = multiplicar(entrada, hayResultadoAnterior, resultadoOpBasicas);
					escribirResultado(resultadoOpBasicas, entrada);
					hayResultadoAnterior = true;
					break;
				case "4":
					//division
					resultadoOpBasicas = dividir(entrada, hayResultadoAnterior, resultadoOpBasicas);
					escribirResultado(resultadoOpBasicas, entrada);
					hayResultadoAnterior = true;
					break;
				case "5":
					//residuo
					resultado = calcularResiduo(entrada);
					escribirResultado(resultado, entrada);
					break;
				case "6":
					//raiz
					resultado = calcularRaiz(entrada);
					escribirResultado(resultado, entrada);
					break;
				case "7":
					//potencia
					resultado = calcularPotencia(entrada);
					escribirResultado(resultado, entrada);
					break;
				case "8":
					//submenu calculos discretos
					continuarPrincipal = manejarSubmenuCalculosDiscretos(entrada);
					break;
				case "9":
					//submenu conversion numerica
					continuarPrincipal = manejarSubmenuConversionesNumericas(entrada);
					break;
				case "10":
					//salir
					continuarPrincipal = false;
					break;
				default:
					//continuar
					break;
			}

		} while (continuarPrincipal);
		System.out.println("Programa finalizado.");
		entrada.close();
	}

	/**
	 * Escribe en pantalla las opciones del menu principal
	 */
	public static void escribirMenuPrincipal() {
		System.out.print("\033[H\033[2J");
		System.out.flush();
		System.out.println("===MENU PRINCIPAL===");
		System.out.println("1. Sumar");
		System.out.println("2. Restar");
		System.out.println("3. Multiplicar");
		System.out.println("4. Dividir");
		System.out.println("5. Residuo (Módulo)");
		System.out.println("6. Raiz x");
		System.out.println("7. Potencia x");
		System.out.println("8. Cálculos Discretos");
		System.out.println("9. Conversiónes numéricas");
		System.out.println("10. Finalizar Programa");
	}

	/**
	 * Escribe en pantalla el resultado de una operación
	 *
	 * @param resultado
	 * @param entrada
	 */
	public static void escribirResultado(double resultado, Scanner entrada) {
		System.out.println("El resultado es:");
		System.out.println(resultado);
		System.out.println("Presione ENTER para continuar...");
		entrada.nextLine();
	}

	/**
	 * Maneja la seleccion si se usa el resultado de una operacion basica anterior
	 *
	 * @param entrada
	 * @param resultadoAnterior
	 * @return true si se quiere usar el resultado anterior
	 */
	public static boolean usarResultadoAnterior(Scanner entrada, double resultadoAnterior) {
		//pregunta si se desea usar resultado anterior
		System.out.print("Desea usar el resultado de la operacion anterior (" + resultadoAnterior + "). [S/n] ? ");
		return "s".equalsIgnoreCase(entrada.nextLine());//si la respuesta es "s" entonces usamos resultado anterior
	}

	/**
	 * Suma una serie de numeros ingresados por el usuario
	 *
	 * @param entrada
	 * @param hayResultadoAnterior
	 * @param resultadoOpBasicas
	 * @return el total de la suma
	 */
	public static double sumar(Scanner entrada, boolean hayResultadoAnterior, double resultadoOpBasicas) {
		int cantidadNumeros;
		double sumador = 0;
		int contador = 0;
		System.out.println("Cuántos numeros desea sumar?");
		cantidadNumeros = Integer.parseInt(entrada.nextLine());
		//si queremos usar resultado anterior entonces solicitamos un numero menos al usuario
		if (hayResultadoAnterior && usarResultadoAnterior(entrada, resultadoOpBasicas)) {
			contador = 1;
			sumador = resultadoOpBasicas;//inicializamos sumador con el valor del resultado anterior
		}
		for (int i = contador; i < cantidadNumeros; i++) {//solicitamos numeros y los sumamos al sumador
			System.out.println("Ingrese numero a sumar");
			sumador += Double.parseDouble(entrada.nextLine());
		}
		return sumador;
	}

	/**
	 * Resta dos numeros
	 *
	 * @param entrada
	 * @param hayResultadoAnterior
	 * @param resultadoOpBasicas
	 * @return la diferencia de los dos numeros
	 */
	public static double restar(Scanner entrada, boolean hayResultadoAnterior, double resultadoOpBasicas) {
		double minuendo;
		double sustraendo;
		//mostrar titulo de minuendo solo cuando hay resultado anterior
		if (hayResultadoAnterior) {
			System.out.println("Minuendo:");
		}
		if (hayResultadoAnterior && usarResultadoAnterior(entrada, resultadoOpBasicas)) {
			minuendo = resultadoOpBasicas;//el minuendo es el resultado anterior
		} else {
			//de lo contrario solicitamos minuendo a usuario
			System.out.println("Ingrese minuendo");
			minuendo = Double.parseDouble(entrada.nextLine());
		}

		//mostrar titulo de Sustraendo solo cuando hay resultado anterior
		if (hayResultadoAnterior) {
			System.out.println("Sustraendo:");
		}
		if (hayResultadoAnterior && usarResultadoAnterior(entrada, resultadoOpBasicas)) {
			sustraendo = resultadoOpBasicas;//el sustraendo es el resultado anterior
		} else {
			//de lo contrario solicitamos sustraendo a usuario
			System.out.println("Ingrese sustraendo");
			sustraendo = Double.parseDouble(entrada.nextLine());
		}
		return minuendo - sustraendo;
	}

	/**
	 * Calcula el producto de una serie de numeros ingresados por el usuario
	 *
	 * @param entrada
	 * @param hayResultadoAnterior
	 * @param resultadoOpBasicas
	 * @return el total del producto
	 */
	public static double multiplicar(Scanner entrada, boolean hayResultadoAnterior, double resultadoOpBasicas) {
		int cantidadNumeros;
		double producto = 1;
		int contador = 0;
		System.out.println("Cuántos numeros desea multiplicar?");
		cantidadNumeros = Integer.parseInt(entrada.nextLine());
		//si queremos usar resultado anterior entonces solicitamos un numero menos al usuario
		if (hayResultadoAnterior && usarResultadoAnterior(entrada, resultadoOpBasicas)) {
			contador = 1;
			producto = resultadoOpBasicas;//inicializamos el producto con el valor del resultado anterior
		}
		for (int i = contador; i < cantidadNumeros; i++) {//solicitamos numeros y los multiplicamos al producto
			System.out.println("Ingrese un factor de la multiplicación");
			producto *= Double.parseDouble(entrada.nextLine());
		}
		return producto;
	}

	/**
	 * Divide dos numeros
	 *
	 * @param entrada
	 * @param hayResultadoAnterior
	 * @param resultadoOpBasicas
	 * @return la division de los dos numeros
	 */
	public static double dividir(Scanner entrada, boolean hayResultadoAnterior, double resultadoOpBasicas) {
		double dividendo;
		double divisor;
		//mostrar titulo de dividendo solo cuando hay resultado anterior
		if (hayResultadoAnterior) {
			System.out.println("Dividendo:");
		}
		if (hayResultadoAnterior && usarResultadoAnterior(entrada, resultadoOpBasicas)) {
			dividendo = resultadoOpBasicas;//el dividendo es el resultado anterior
		} else {
			//de lo contrario solicitamos dividendo a usuario
			System.out.println("Ingrese dividendo");
			dividendo = Double.parseDouble(entrada.nextLine());
		}

		//mostrar titulo de divisor solo cuando hay resultado anterior
		if (hayResultadoAnterior) {
			System.out.println("Divisor:");
		}
		if (hayResultadoAnterior && usarResultadoAnterior(entrada, resultadoOpBasicas)) {
			divisor = resultadoOpBasicas;//el divisor es el resultado anterior
		} else {
			//de lo contrario solicitamos sustraendo a usuario
			System.out.println("Ingrese divisor");
			divisor = Double.parseDouble(entrada.nextLine());
		}
		return dividendo / divisor;
	}

	/**
	 * Calcula el calcularResiduo de dos numeros
	 *
	 * @param entrada
	 * @return el calcularResiduo de los dos numeros
	 */
	public static int calcularResiduo(Scanner entrada) {
		int dividendo;
		int divisor;
		System.out.println("Ingrese dividendo");
		dividendo = Integer.parseInt(entrada.nextLine());
		System.out.println("Ingrese divisor");
		divisor = Integer.parseInt(entrada.nextLine());
		return dividendo % divisor;
	}

	/**
	 * Calcula la raiz x de un numero
	 *
	 * @param entrada
	 * @return la raiz de un numero
	 */
	public static double calcularRaiz(Scanner entrada) {
		double indice;
		double radicando;
		System.out.println("Ingrese indice de la raiz");
		indice = Double.parseDouble(entrada.nextLine());
		System.out.println("Ingrese radicando");
		radicando = Double.parseDouble(entrada.nextLine());
		return Math.pow(radicando, 1 / indice);//la raiz es elevar un numero a la calcularPotencia 1 / indice de raiz
	}

	/**
	 * Calcula la potencia x de un numero
	 *
	 * @param entrada
	 * @return la potencia de un numero
	 */
	public static double calcularPotencia(Scanner entrada) {
		double exponente;
		double base;
		System.out.println("Ingrese base de la potencia");
		base = Double.parseDouble(entrada.nextLine());
		System.out.println("Ingrese exponente de la potencia");
		exponente = Double.parseDouble(entrada.nextLine());
		return Math.pow(base, exponente);
	}

	/**
	 * Metodo para gestionar las opciones del submenu Calculos discretos
	 *
	 * @param entrada
	 * @return true si se desea continuar el programa, false si se desea terminar
	 */
	public static boolean manejarSubmenuCalculosDiscretos(Scanner entrada) {
		boolean continuarSubmenu = true;
		boolean continuarPrograma = true;
		String opcion;
		double resultado;
		do {
			//Escribir submenu
			escribirSubmenuCalculosDiscretos();
			//leer opcion
			opcion = entrada.nextLine();
			switch (opcion) {
				case "1":
					//factorial
					resultado = calcularFactorial(entrada);
					escribirResultado(resultado, entrada);
					break;
				case "2":
					//permutacion
					resultado = calcularPermutacion(entrada);
					escribirResultado(resultado, entrada);
					break;
				case "3":
					//combinacion
					resultado = calcularCombinacion(entrada);
					escribirResultado(resultado, entrada);
					break;
				case "4":
					//regresar a menu principal
					continuarSubmenu = false;
					break;
				case "5":
					//finalizar programa
					continuarSubmenu = false;
					continuarPrograma = false;
					break;
				default:
					//continuar submenu
					break;
			}
		} while (continuarSubmenu);
		return continuarPrograma;
	}

	/**
	 * Escribe en pantalla las opciones del submenu calculos discretos
	 */
	public static void escribirSubmenuCalculosDiscretos() {
		System.out.print("\033[H\033[2J");
		System.out.flush();
		System.out.println("===SUBMENU CALCULOS DISCRETOS===");
		System.out.println("1. Factorial");
		System.out.println("2. Permutacion P(n,r)");
		System.out.println("3. Combinacion C(n,r)");
		System.out.println("4. Regresar al menu principal");
		System.out.println("5. Finalizar Programa");
	}

	/**
	 * Genera el factorial de un numero entero
	 *
	 * @param numero
	 * @return el factorial del numero
	 */
	public static double generarFactorial(int numero) {
		double resultado = 1;
		//se tiene un contador i que se incrementa en uno hasta ser igual al numero ingresado,
		//por cada ciclo se multiplica el contador por el resultado de la multiplicacion anterior.
		//ejemplo: si numero = 5 entonces el factorial se forma: 1 * 2 * 3 * 4 * 5
		for (int i = 1; i <= numero; i++) {
			resultado *= i;
		}
		return resultado;
	}

	/**
	 * Metodo para solicitar un numero entero y calcular el factorial
	 *
	 * @param entrada
	 * @return el resultado del factorial
	 */
	public static double calcularFactorial(Scanner entrada) {
		int numero;
		System.out.println("Ingrese un numero entero");
		numero = Integer.parseInt(entrada.nextLine());
		return generarFactorial(numero);
	}

	/**
	 * Metodo para calcular la permutacion de 'n' numeros tomando 'r' elementos
	 *
	 * @param entrada
	 * @return el resultado de la permutacion
	 */
	public static double calcularPermutacion(Scanner entrada) {
		int numeroN;
		int numeroR;
		System.out.println("Ingrese el numero 'n'");
		numeroN = Integer.parseInt(entrada.nextLine());
		System.out.println("Ingrese el numero 'r'");
		numeroR = Integer.parseInt(entrada.nextLine());
		//se reutiliza la funcion factorial
		return generarFactorial(numeroN) / generarFactorial(numeroN - numeroR);
	}

	/**
	 * Metodo para calcular la combinacion de 'n' numeros tomando 'r' elementos
	 *
	 * @param entrada
	 * @return el resultado de la combinacion
	 */
	public static double calcularCombinacion(Scanner entrada) {
		int numeroN;
		int numeroR;
		System.out.println("Ingrese el numero 'n'");
		numeroN = Integer.parseInt(entrada.nextLine());
		System.out.println("Ingrese el numero 'r'");
		numeroR = Integer.parseInt(entrada.nextLine());
		//se reutiliza la funcion factorial
                System.out.println(generarFactorial(numeroN));
		return generarFactorial(numeroN) / (generarFactorial(numeroN - numeroR) * generarFactorial(numeroR));
	}
	
	/**
	 * Metodo para gestionar las opciones del submenu Conversiones numericas
	 *
	 * @param entrada
	 * @return true si se desea continuar el programa, false si se desea terminar
	 */
	public static boolean manejarSubmenuConversionesNumericas(Scanner entrada) {
		boolean continuarSubmenu = true;
		boolean continuarPrograma = true;
		String opcion;
		String resultado;
		do {
			//Escribir submenu
			escribirSubmenuConversionesNumericas();
			//leer opcion
			opcion = entrada.nextLine();
			switch (opcion) {
				case "1":
					//decimal a binario
					resultado = convertirABinario(entrada);
					escribirResultadoConversion(resultado, entrada);
					break;
				case "2":
					//decimal a hexa
					resultado = convertirAHexadecimal(entrada);
					escribirResultadoConversion(resultado, entrada);
					break;
				case "3":
					//decimal a octal
					resultado = convertirAOctal(entrada);
					escribirResultadoConversion(resultado, entrada);
					break;
				case "4":
					//regresar a menu principal
					continuarSubmenu = false;
					break;
				case "5":
					//finalizar programa
					continuarSubmenu = false;
					continuarPrograma = false;
					break;
				default:
					//continuar submenu
					break;
			}
		} while (continuarSubmenu);
		return continuarPrograma;
	}
	
	/**
	 * Escribe en pantalla las opciones del submenu calculos discretos
	 */
	public static void escribirSubmenuConversionesNumericas() {
		System.out.print("\033[H\033[2J");
		System.out.flush();
		System.out.println("===SUBMENU CONVERSIONES NUMERICAS===");
		System.out.println("1. Decimal a binario");
		System.out.println("2. Decimal a hexadecimal");
		System.out.println("3. Decimal a octal");
		System.out.println("4. Regresar al menu principal");
		System.out.println("5. Finalizar Programa");
	}
	
	/**
	 * Escribe en pantalla el resultado de una operación de conversion
	 *
	 * @param resultado
	 * @param entrada
	 */
	public static void escribirResultadoConversion(String resultado, Scanner entrada) {
		System.out.println("El resultado de la conversión es:");
		System.out.println(resultado);
		System.out.println("Presione ENTER para continuar...");
		entrada.nextLine();
	}
	
	/**
	 * Convierte un entero a cadena binaria
	 * @param entrada 
	 * @return  la cadena resultado
	 */
	public static String convertirABinario(Scanner entrada) {
		int numero;
		int cociente;
		int residuo;
		String cadenaResultado = "";
		System.out.println("Ingrese el numero a convertir");
		numero = Integer.parseInt(entrada.nextLine());
		cociente = numero;
		while(cociente != 0) {//terminamos cuando ya no se pueda dividir el numero por el valor de la base (2)
			residuo = cociente % 2;
			cociente = cociente / 2;//obtenemos el cociente sobre el cual operaremos en el siguiente ciclo
			//el residuo es parte de la cadena de resultado binario
			//agregamos el residuo altual al inicio de la cadena para mantener el correcto orden
			cadenaResultado = residuo + cadenaResultado;
		}
		return cadenaResultado;
	}
	
	/**
	 * Convierte un entero a cadena hexadecimal
	 * @param entrada 
	 * @return  la cadena resultado
	 */
	public static String convertirAHexadecimal(Scanner entrada) {
		int numero;
		int cociente;
		int residuo;
		String residuoString;
		String cadenaResultado = "";
		System.out.println("Ingrese el numero a convertir");
		numero = Integer.parseInt(entrada.nextLine());
		cociente = numero;
		while(cociente != 0) {//terminamos cuando ya no se pueda dividir el numero por el valor de la base (16)
			residuo = cociente % 16;
			cociente = cociente / 16;//obtenemos el cociente sobre el cual operaremos en el siguiente ciclo
			switch (residuo) {//en hexadecimal, los digitos mas allá del decimo hasta el quinceavo se representan con letras
				case 10:
					residuoString = "A";
					break;
				case 11:
					residuoString = "B";
					break;
				case 12:
					residuoString = "C";
					break;
				case 13:
					residuoString = "D";
					break;
				case 14:
					residuoString = "E";
					break;
				case 15:
					residuoString = "F";
					break;
				default:
					residuoString = String.valueOf(residuo);//convertimos a cadena el residuo y lo asignamos
			}
			//el residuo es parte de la cadena de resultado binario
			//agregamos el residuo altual al inicio de la cadena para mantener el correcto orden
			cadenaResultado = residuoString + cadenaResultado;
		}
		return cadenaResultado;
	}
	
	/**
	 * Convierte un entero a cadena octal
	 * @param entrada 
	 * @return  la cadena resultado
	 */
	public static String convertirAOctal(Scanner entrada) {
		int numero;
		int cociente;
		int residuo;
		String cadenaResultado = "";
		System.out.println("Ingrese el numero a convertir");
		numero = Integer.parseInt(entrada.nextLine());
		cociente = numero;
		while(cociente != 0) {//terminamos cuando ya no se pueda dividir el numero por el valor de la base (8)
			residuo = cociente % 8;
			cociente = cociente / 8;//obtenemos el cociente sobre el cual operaremos en el siguiente ciclo
			//el residuo es parte de la cadena de resultado binario
			//agregamos el residuo altual al inicio de la cadena para mantener el correcto orden
			cadenaResultado = residuo + cadenaResultado;
		}
		return cadenaResultado;
	}
}